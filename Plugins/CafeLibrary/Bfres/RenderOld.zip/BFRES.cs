﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using GLFrameworkEngine;
using Toolbox.Core.ViewModels;
using Toolbox.Core;
using Toolbox.Core.Hashes;
using BfresLibrary;
using MapStudio.UI;
using CafeLibrary.Rendering;
using Syroot.NintenTools.NSW.Bntx;
using OpenTK;
using ImGuiNET;

namespace CafeLibrary
{
    public class BFRES : FileEditor, IFileFormat, IDisposable
    {
        public string[] Description => new string[] { "bfres" };

        public string[] Extension => new string[] { ".bfres" };

        public bool CanSave { get; set; }
        public File_Info FileInfo { get; set; }

        public bool Identify(File_Info fileInfo, Stream stream)
        {
            using (var reader = new Toolbox.Core.IO.FileReader(stream, true)) {
                return reader.CheckSignature(4, "FRES");
            }
        }

        //renderer
        public BfresRender Renderer;

        //Tree Nodes
        private ModelFolder ModelFolder;
        private TextureFolder TextureFolder;

        public ModelImportSettings ImportSettings = new ModelImportSettings();

        ResFile ResFile { get; set; }

        string ModelHash;

        public void Load(Stream stream)
        {
            ResFile = new ResFile(stream);
            Renderer = new BfresRender();
            Renderer.Name = FileInfo.FilePath;
            Renderer.CanSelect = false;

            BfresLoader.LoadShaders(ResFile, Renderer);

            ModelHash = MD5.Calculate(FileInfo.FilePath);

            BntxFile bntx = new BntxFile();
            if (ResFile.IsPlatformSwitch)
            {
                foreach (var file in ResFile.ExternalFiles.Values)
                    if (file.LoadedFileData is BntxFile)
                        bntx = file.LoadedFileData as BntxFile;
            }

            TextureFolder = new TextureFolder(ResFile, bntx);
            ModelFolder = new ModelFolder(this, ResFile);

            foreach (var texNode in TextureFolder.Children) {
                var tex = texNode.Tag as STGenericTexture;
                Renderer.Textures.Add(tex.Name, new GenericRenderer.TextureView(tex));
            }

            //Using events for when the textures are updated
            //This is to help seperate editing vs rendering
            TextureFolder.OnTextureAdded += (o, e) =>
            {
                var node = o as TextureNode;
                Renderer.Textures.Add(node.Header,
                    new GenericRenderer.TextureView(node.Tag as STGenericTexture));
                GLContext.ActiveContext.UpdateViewport = true;
            };
            TextureFolder.OnTextureRemoved += (o, e) =>
            {
                var node = o as TextureNode;
                Renderer.Textures[node.Header]?.RenderTexture?.Dispose();
                Renderer.Textures.Remove(node.Header);
                GLContext.ActiveContext.UpdateViewport = true;
            };
            TextureFolder.OnTextureReplaced += (o, e) =>
            {
                var node = o as TextureNode;
                Renderer.Textures[node.Header]?.RenderTexture?.Dispose();
                Renderer.Textures.Remove(node.Header);

                Renderer.Textures.Add(node.Header,
        new GenericRenderer.TextureView(node.Tag as STGenericTexture));
                GLContext.ActiveContext.UpdateViewport = true;
            };

            Root.AddChild(ModelFolder);
            Root.AddChild(TextureFolder);

            Root.ContextMenus.Clear();
            Root.ContextMenus.Add(new MenuItemModel("Save", SaveDialog));

            GLContext.ActiveContext.ColorPicker.PickingMode = ColorPicker.SelectionMode.Mesh;

            AddRender(Renderer);

            if (!DataCache.ModelCache.ContainsKey(Renderer.Name))
                DataCache.ModelCache.Add(Renderer.Name, Renderer);
        }

        public void UpdateMaterialData(Model fmdl, Shape shape, Material material)
        {
            //Find the matching model renderer for the model/mesh
            foreach (BfresModelRender model in Renderer.Models) {
                if (fmdl.Name != model.Name)
                    continue;

                foreach (BfresMeshRender mesh in model.MeshList) {
                    if (mesh.Name == shape.Name) //Update material instance of the mesh
                        BfresLoader.UpdateMaterial(Renderer, model, mesh, shape, material);
                }
            }
            GLContext.ActiveContext.UpdateViewport = true;
        }

        public void ExportTextures(string folder)
        {
            TextureFolder.ExportAllTextures(folder);
        }

        private void SaveDialog()
        {
            ImguiFileDialog dlg = new ImguiFileDialog();
            dlg.SaveDialog = true;
            dlg.FileName = this.FileInfo.FileName;
            dlg.AddFilter(".szs", ".szs");
            dlg.AddFilter(".bfres", ".bfres");
            foreach (var ext in TextureDialog.SupportedExtensions)
                dlg.AddFilter(ext, ext);

            if (dlg.ShowDialog()) {
                var log = Toolbox.Core.IO.STFileSaver.SaveFileFormat(this, dlg.FilePath);
                TinyFileDialog.MessageBoxInfoOk($"Saved {dlg.FilePath} in {log.SaveTime}!");
            }
        }

        public override bool OnFileDrop(string filePath)
        {
            if (filePath.EndsWith(".png") || 
                filePath.EndsWith(".dds") ||
                filePath.EndsWith(".bftex"))
            {
                TextureFolder.ImportTexture(filePath);
                return true;
            }
            if (filePath.EndsWith(".dae") ||
                filePath.EndsWith(".fbx") ||
                filePath.EndsWith(".bfmdl"))
            {
                var model = ModelFolder.Children.FirstOrDefault().Tag as FMDL;
                model.AddModel(filePath);
                return true;
            }
            return base.OnFileDrop(filePath);
        }

        public override void OnKeyDown(KeyEventInfo keyEventInfo)
        {
            if (keyEventInfo.IsKeyDown(InputSettings.INPUT.Scene.Delete)) {
                Renderer.RemoveSelected();
            }
            if (keyEventInfo.IsKeyDown(InputSettings.INPUT.Scene.SelectAll)) {
                foreach (BfresModelRender model in Renderer.Models) {
                    foreach (BfresMeshRender mesh in model.Meshes) {
                        mesh.IsSelected = true;
                    }
                }
            }
        }

        public override void OnEnter()
        {
            var hash = MD5.Calculate(FileInfo.FilePath);
            //Update the model if the file has been edited externally
            if (hash == ModelHash)
                return;

            ModelHash = hash;
         //   ResFile = new ResFile(FileInfo.FilePath);
        }

        public void Save(Stream stream) {
            TextureFolder.OnSave();
            ModelFolder.OnSave();

            ResFile.Save(stream);
        }

        public void Dispose() {
            DataCache.ModelCache.Remove(Renderer.Name);
        }

        public override void DrawToolWindow()
        {
            if (ImGui.Button("Model Settings"))
            {
                ImGui.OpenPopup("model_settings");
            }
            if (ImGui.Button("Texture Settings"))
            {
                ImGui.OpenPopup("texture_settings");
            }

            if (ImGui.BeginPopup("model_settings"))
            {
                ImGui.EndPopup();
            }

            if (ImGui.BeginPopup("texture_settings"))
            {
                ImGui.EndPopup();
            }
        }
    }
}
