﻿using System;
using System.Collections.Generic;
using System.Linq;
using BfresLibrary.Helpers;
using BfresLibrary;
using BfresLibrary.GX2;
using System.IO;
using Syroot.Maths;
using Toolbox.Core.IO;
using Toolbox.Core;
using BfresLibrary.TextConvert;
using IONET.Core.Skeleton;
using IONET.Core.Model;
using IONET.Core;
using IONET;

namespace CafeLibrary.ModelConversion
{
    public class BfresModelImporter
    {
        static System.Numerics.Matrix4x4 GlobalTransform;

        public static Model ImportModel(ResFile resFile, string filePath)
        {
            if (filePath.EndsWith(".bfmdl"))
            {
                Model model = new Model();
                model.Import(filePath, resFile);
                return model;
            }

            var settings = new ImportSettings()
            {
                Optimize = true,
                GenerateTangentsAndBinormals = true,
            };

            GlobalTransform = System.Numerics.Matrix4x4.Identity;
            IOScene scene = IOManager.LoadScene(filePath, settings);

            var fmdl = ConvertScene(resFile, scene);
            fmdl.Name = Path.GetFileNameWithoutExtension(filePath);
            return fmdl;
        }

        static Model ConvertScene(ResFile resFile, IOScene scene)
        {
            var model = scene.Models.FirstOrDefault();

            Model fmdl = new Model();
            fmdl.Name = model.Name;

            foreach (var mat in scene.Materials)
            {
                Material fmat = new Material();
                fmat.Name = mat.Label;
                if (mat.DiffuseMap != null)
                {
                    fmat.Samplers.Add("_a0", new Sampler() { Name = "_a0", TexSampler = new TexSampler()});
                    fmat.TextureRefs.Add(new TextureRef() { Name = mat.DiffuseMap.Name });
                }
                fmdl.Materials.Add(fmat.Name, fmat);
            }

            fmdl.Skeleton = new Skeleton();
            fmdl.Skeleton.FlagsRotation = SkeletonFlagsRotation.EulerXYZ;

            foreach (var bone in model.Skeleton.BreathFirstOrder())
            {
                Vector4F rotation = new Vector4F(
                    bone.RotationEuler.X,
                    bone.RotationEuler.Y,
                    bone.RotationEuler.Z,
                    1.0f);

                //Convert to quaternion if setting is used
                if (fmdl.Skeleton.FlagsRotation == SkeletonFlagsRotation.Quaternion)
                {
                    var quat = STMath.FromEulerAngles(new OpenTK.Vector3(
                        bone.RotationEuler.X,
                        bone.RotationEuler.Y,
                        bone.RotationEuler.Z));
                    rotation = new Vector4F(quat.X, quat.Y, quat.Z, quat.W);
                }

                var bfresBone = new Bone()
                {
                    FlagsRotation = BoneFlagsRotation.EulerXYZ,
                    FlagsTransform = SetBoneFlags(bone),
                    Name = bone.Name,
                    RigidMatrixIndex = -1,  //Gets calculated after
                    SmoothMatrixIndex = -1, //Gets calculated after
                    ParentIndex = (short)model.Skeleton.IndexOf(bone.Parent),
                    Position = new Vector3F(
                         bone.Translation.X,
                         bone.Translation.Y,
                         bone.Translation.Z),
                    Scale = new Vector3F(
                         bone.Scale.X,
                         bone.Scale.Y,
                         bone.Scale.Z),
                    Rotation = rotation,
                    Visible = true,
                };
                fmdl.Skeleton.Bones.Add(bone.Name, bfresBone);
            }
            if (fmdl.Skeleton.Bones.Count == 0) {
                fmdl.Skeleton.Bones.Add("Root", new Bone());
            }

            List<int> smoothSkinningIndices = new List<int>();
            List<int> rigidSkinningIndices = new List<int>();

            uint[] skinCounts = new uint[model.Meshes.Count];
            int sindex = 0;

            //Determine the rigid and smooth bone skinning
            foreach (var mesh in model.Meshes)
            {
                if (mesh.Vertices.Count == 0)
                    continue;

                //Set the skin count
                uint vertexSkinCount = CalculateSkinCount(mesh.Vertices);

                //Set the skin count for each mesh. This is either calculated or applied via mesh meta info
                skinCounts[sindex++] = vertexSkinCount;

                foreach (var vertex in mesh.Vertices)
                {
                    foreach (var weight in vertex.Envelope.Weights)
                    {
                        var bn = fmdl.Skeleton.Bones.Values.Where(x => x.Name == weight.BoneName).FirstOrDefault();
                        if (bn != null)
                        {
                            int index = fmdl.Skeleton.Bones.IndexOf(bn);

                            //Rigid skinning
                            if (vertexSkinCount == 1)
                            {
                                if (!rigidSkinningIndices.Contains(index))
                                    rigidSkinningIndices.Add(index);
                            }
                            else
                            {
                                if (!smoothSkinningIndices.Contains(index))
                                    smoothSkinningIndices.Add(index);
                            }
                        }
                    }
                }
            }

            //Sort indices
            smoothSkinningIndices.Sort();
            rigidSkinningIndices.Sort();

            //Create a global skinning list. Smooth indices first, rigid indices last
            List<int> skinningIndices = new List<int>();
            skinningIndices.AddRange(smoothSkinningIndices);
            skinningIndices.AddRange(rigidSkinningIndices);

            //Next update the bone's skinning index value
            foreach (var index in smoothSkinningIndices)
            {
                var bone = fmdl.Skeleton.Bones[index];
                bone.SmoothMatrixIndex = (short)smoothSkinningIndices.IndexOf(index);
            }
            //Rigid indices go after smooth indices
            //Here we do not index the global iist as the global list can include the same index in both smooth/rigid
            foreach (var index in rigidSkinningIndices)
            {
                var bone = fmdl.Skeleton.Bones[index];
                bone.RigidMatrixIndex = (short)(smoothSkinningIndices.Count + rigidSkinningIndices.IndexOf(index));
            }

            //Turn them into ushorts for the final list in the binary
            fmdl.Skeleton.MatrixToBoneList = new List<ushort>();
            for (int i = 0; i < skinningIndices.Count; i++)
                fmdl.Skeleton.MatrixToBoneList.Add((ushort)skinningIndices[i]);

            //Generate inverse matrices
            fmdl.Skeleton.InverseModelMatrices = new List<Matrix3x4>();
            foreach (var bone in fmdl.Skeleton.Bones.Values)
            {
                //Set identity types for none smooth bones
                bone.InverseMatrix = new Matrix3x4(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0);

                //Inverse matrices are used for smooth bone skinning
                if (bone.SmoothMatrixIndex == -1)
                    continue;

                var transform = MatrixExenstion.GetMatrixInverted(fmdl.Skeleton, bone);
                //Assign the inverse matrix directly for older versions that store it directly
                bone.InverseMatrix = transform;
                //Add it to the global inverse list
                fmdl.Skeleton.InverseModelMatrices.Add(transform);
            }

            int meshIndex = 0;
            foreach (var mesh in model.Meshes)
            {
                if (mesh.Vertices.Count == 0)
                    continue;

                var settings = new MeshSettings()
                {
                    UseBoneIndices = true,
                    UseBoneWeights = true,
                    UseNormal = true,
                    UseTangents = true,
                    UseTexCoord = new bool[5] { true, true, true, true, true, },
                    UseColor = new bool[5] { true, true, true, true, true, },
                };

                var names = fmdl.Shapes.Values.Select(x => x.Name).ToList();

                Shape fshp = new Shape();
                fshp.Name = Utils.RenameDuplicateString(mesh.Name, names, 0, 2);
                fshp.MaterialIndex = 0;
                fshp.BoneIndex = 0;
                fshp.VertexSkinCount = (byte)skinCounts[meshIndex++];

                fshp.SkinBoneIndices = new List<ushort>();
                foreach (var vertex in mesh.Vertices)
                {
                    foreach (var weight in vertex.Envelope.Weights)
                    {
                        var bn = fmdl.Skeleton.Bones.Values.Where(x => x.Name == weight.BoneName).FirstOrDefault();
                        if (bn != null)
                        {
                            ushort index = (ushort)fmdl.Skeleton.Bones.IndexOf(bn);
                            if (!fshp.SkinBoneIndices.Contains(index))
                                fshp.SkinBoneIndices.Add(index);
                        }
                    }
                }

                //Get the original material and map by string key
                string material = mesh.Polygons[0].MaterialName;

                int materialIndex = fmdl.Materials.IndexOf(material);
                if (materialIndex != -1)
                    fshp.MaterialIndex = (ushort)materialIndex;
                else
                    Console.WriteLine($"Failed to find material {material}");

                //Only add a root node for bounding node tree
                fshp.SubMeshBoundingIndices.Add(0);
                fshp.SubMeshBoundingNodes.Add(new BoundingNode()
                {
                    LeftChildIndex = 0,
                    RightChildIndex = 0,
                    NextSibling = 0,
                    SubMeshIndex = 0,
                    Unknown = 0,
                    SubMeshCount = 1,
                });

                //Generate a vertex buffer
                VertexBuffer buffer = GenerateVertexBuffer(resFile, mesh, fshp,
                    settings, model.Skeleton.BreathFirstOrder(), fmdl.Skeleton, rigidSkinningIndices, smoothSkinningIndices);

                fshp.VertexBufferIndex = (ushort)fmdl.VertexBuffers.Count;
                fshp.VertexSkinCount = (byte)buffer.VertexSkinCount;
                fmdl.VertexBuffers.Add(buffer);

                try
                {


                }
                catch (Exception ex)
                {
                    throw new Exception("Failed to generate vertex buffer! \n " + ex.ToString());
                }

                //Generate boundings for the mesh
                //If a mesh's vertex data is split into parts, we can create sub meshes with their own boundings
                //Sub meshes are used for large meshes where they need to cull parts of a mesh from it's bounding box
                //Sub meshes do not allow multiple materials, that is from the shape itself
                //These are added in the order of the index list, with an offset/count for the indices being used as a sub mesh
                var boundingBox = CalculateBoundingBox(mesh.Vertices, model.Skeleton.BreathFirstOrder(), fshp.VertexSkinCount > 0);
                fshp.SubMeshBoundings.Add(boundingBox); //Create bounding for total mesh
                fshp.SubMeshBoundings.Add(boundingBox); //Create bounding for single sub meshes

                Vector3F min = boundingBox.Center - boundingBox.Extent;
                Vector3F max = boundingBox.Center + boundingBox.Extent;

                var sphereRadius = GetBoundingSphereFromRegion(new Vector4F(
                    min.X, min.Y, min.Z, 1), new Vector4F(max.X, max.Y, max.Z, 1));

                fshp.RadiusArray.Add(sphereRadius); //Total radius (per LOD)

                Console.WriteLine($"BOUDNING {sphereRadius}");

                //A mesh represents a single level of detail. Here we can create additional level of detail meshes if supported.
                Mesh bMesh = new Mesh();
                bMesh.PrimitiveType = GX2PrimitiveType.Triangles;

                var poly = mesh.Polygons[0];

                GX2IndexFormat Format = GX2IndexFormat.UInt16;
                if (resFile.IsPlatformSwitch)
                {
                    Format = GX2IndexFormat.UInt16LittleEndian;
                    if (poly.Indicies.Any(x => x > ushort.MaxValue))
                        Format = GX2IndexFormat.UInt32LittleEndian;
                }
                else
                {
                    if (poly.Indicies.Any(x => x > ushort.MaxValue))
                        Format = GX2IndexFormat.UInt32;
                }

                bMesh.SetIndices(poly.Indicies.Select(x => (uint)x).ToList(), Format);
                bMesh.SubMeshes.Add(new SubMesh()
                {
                    Offset = 0,
                    Count = (uint)poly.Indicies.Count,
                });
                //Add the lod to the shape
                fshp.Meshes.Add(bMesh);

                //Finally add the shape to the model
                fmdl.Shapes.Add(fshp.Name, fshp);
            }

            return fmdl;
        }

        private static float CalculateRadius(float horizontalLeg, float verticalLeg)
        {
            return (float)Math.Sqrt((horizontalLeg * horizontalLeg) + (verticalLeg * verticalLeg));
        }

        private static float GetBoundingSphereFromRegion(Vector4F min, Vector4F max)
        {
            // The radius should be the hypotenuse of the triangle.
            // This ensures the sphere contains all points.
            Vector4F lengths = max - min;
            return CalculateRadius(lengths.X / 2.0f, lengths.Y / 2.0f);
        }

        private static BoneFlagsTransform SetBoneFlags(IOBone bn)
        {
            BoneFlagsTransform flags = BoneFlagsTransform.None;
            if (bn.Translation == System.Numerics.Vector3.Zero)
                flags |= BoneFlagsTransform.TranslateZero;
            if (bn.RotationEuler == System.Numerics.Vector3.Zero)
                flags |= BoneFlagsTransform.RotateZero;
            if (bn.Scale == System.Numerics.Vector3.One)
                flags |= BoneFlagsTransform.ScaleOne;
            return flags;
        }

        private static byte CalculateSkinCount(List<IOVertex> vertices)
        {
            uint numSkinning = 0;
            for (int v = 0; v < vertices.Count; v++)
                numSkinning = Math.Max(numSkinning, (uint)vertices[v].Envelope.Weights.Count);
            return (byte)numSkinning;
        }

        private static Dictionary<string, AABB> CalculateBoneAABB(List<IOVertex> vertices, List<IOBone> bones)
        {
            Dictionary<string, AABB> skinnedBoundings = new Dictionary<string, AABB>();
            for (int i = 0; i < vertices.Count; i++)
            {
                var vertex = vertices[i];

                foreach (var boneID in vertex.Envelope.Weights)
                {
                    if (!skinnedBoundings.ContainsKey(boneID.BoneName))
                        skinnedBoundings.Add(boneID.BoneName.ToString(), new AABB());

                    var transform = bones.FirstOrDefault(x => x.Name == boneID.BoneName).WorldTransform;
                    System.Numerics.Matrix4x4.Invert(transform, out System.Numerics.Matrix4x4 inverted);

                    //Get the position in local coordinates
                    var position = vertices[i].Position;
                    position = System.Numerics.Vector3.Transform(position, inverted);

                    var bounding = skinnedBoundings[boneID.BoneName];
                    bounding.minX = Math.Min(bounding.minX, position.X);
                    bounding.minY = Math.Min(bounding.minY, position.Y);
                    bounding.minZ = Math.Min(bounding.minZ, position.Z);
                    bounding.maxX = Math.Max(bounding.maxX, position.X);
                    bounding.maxY = Math.Max(bounding.maxY, position.Y);
                    bounding.maxZ = Math.Max(bounding.maxZ, position.Z);
                }
            }
            return skinnedBoundings;
        }

        class AABB
        {
            public float minX = float.MaxValue;
            public float minY = float.MaxValue;
            public float minZ = float.MaxValue;
            public float maxX = float.MinValue;
            public float maxY = float.MinValue;
            public float maxZ = float.MinValue;

            public OpenTK.Vector3 Max => new OpenTK.Vector3(maxX, maxY, maxZ);
            public OpenTK.Vector3 Min => new OpenTK.Vector3(minX, minY, minZ);

        }

        private static Bounding CalculateBoundingBox(List<IOVertex> vertices, List<IOBone> bones, bool isSmoothSkinning)
        {
            float minX = float.MaxValue;
            float minY = float.MaxValue;
            float minZ = float.MaxValue;
            float maxX = float.MinValue;
            float maxY = float.MinValue;
            float maxZ = float.MinValue;

            if (isSmoothSkinning && false)
            {
                var boundings = CalculateBoneAABB(vertices, bones);
                //Find largest bounding box
                foreach (var bounding in boundings.Values)
                {
                    minX = Math.Min(minX, bounding.minX);
                    minY = Math.Min(minY, bounding.minY);
                    minZ = Math.Min(minZ, bounding.minZ);
                    maxX = Math.Max(maxX, bounding.maxX);
                    maxY = Math.Max(maxY, bounding.maxY);
                    maxZ = Math.Max(maxZ, bounding.maxZ);
                }
                return CalculateBoundingBox(
                    new Vector3F(minX, minY, minZ),
                    new Vector3F(maxX, maxY, maxZ));
            }

            for (int i = 0; i < vertices.Count; i++)
            {
                minX = Math.Min(minX, vertices[i].Position.X);
                minY = Math.Min(minY, vertices[i].Position.Y);
                minZ = Math.Min(minZ, vertices[i].Position.Z);
                maxX = Math.Max(maxX, vertices[i].Position.X);
                maxY = Math.Max(maxY, vertices[i].Position.Y);
                maxZ = Math.Max(maxZ, vertices[i].Position.Z);
            }

            return CalculateBoundingBox(
                new Vector3F(minX, minY, minZ),
                new Vector3F(maxX, maxY, maxZ));
        }

        private static Bounding CalculateBoundingBox(Vector3F min, Vector3F max)
        {
            Vector3F center = max + min;

            Console.WriteLine($"min {min}");
            Console.WriteLine($"max {max}");

            float xxMax = GetExtent(max.X, min.X);
            float yyMax = GetExtent(max.Y, min.Y);
            float zzMax = GetExtent(max.Z, min.Z);

            Vector3F extend = new Vector3F(xxMax, yyMax, zzMax);

            return new Bounding()
            {
                Center = new Vector3F(center.X, center.Y, center.Z),
                Extent = new Vector3F(extend.X, extend.Y, extend.Z),
            };
        }



        private static float GetExtent(float max, float min)
        {
            return (float)Math.Max(Math.Sqrt(max * max), Math.Sqrt(min * min));
        }

        private static VertexBuffer GenerateVertexBuffer(ResFile resFile, IOMesh mesh, Shape fshp, MeshSettings settings,
           List<IOBone> bones, Skeleton fskl, List<int> rigidIndices, List<int> smoothIndices)
        {
            VertexBufferHelper vertexBufferHelper = new VertexBufferHelper(
                new VertexBuffer(), resFile.ByteOrder);

            List<Vector4F> Positions = new List<Vector4F>();
            List<Vector4F> Normals = new List<Vector4F>();
            List<Vector4F> BoneWeights = new List<Vector4F>();
            List<Vector4F> BoneIndices = new List<Vector4F>();
            List<Vector4F> Tangents = new List<Vector4F>();
            List<Vector4F> Bitangents = new List<Vector4F>();

            int numTexCoords = mesh.Vertices.FirstOrDefault().UVs.Count;
            int numColors = mesh.Vertices.FirstOrDefault().Colors.Count;

            Vector4F[][] TexCoords = new Vector4F[numTexCoords][];
            Vector4F[][] Colors = new Vector4F[numColors][];

            for (int c = 0; c < numColors; c++)
                Colors[c] = new Vector4F[mesh.Vertices.Count];
            for (int c = 0; c < numTexCoords; c++)
                TexCoords[c] = new Vector4F[mesh.Vertices.Count];

            for (int v = 0; v < mesh.Vertices.Count; v++)
            {
                var vertex = mesh.Vertices[v];

                var position = vertex.Position;
                var normal = vertex.Normal;

                //Reset rigid skinning types to local space
                if (fshp.VertexSkinCount == 0 && bones.Count > 0)
                {
                    var transform = bones[fshp.BoneIndex].WorldTransform;
                    System.Numerics.Matrix4x4.Invert(transform, out System.Numerics.Matrix4x4 inverted);
                    position = System.Numerics.Vector3.Transform(position, inverted);
                    normal = System.Numerics.Vector3.TransformNormal(normal, inverted);
                }
                //Reset rigid skinning types to local space
                if (fshp.VertexSkinCount == 1)
                {
                    var bone = bones.FirstOrDefault(x => x.Name == vertex.Envelope.Weights[0].BoneName);
                    var transform = bone.WorldTransform;
                    System.Numerics.Matrix4x4.Invert(transform, out System.Numerics.Matrix4x4 inverted);
                    position = System.Numerics.Vector3.Transform(position, inverted);
                    normal = System.Numerics.Vector3.TransformNormal(normal, inverted);
                }

                position = System.Numerics.Vector3.Transform(position, GlobalTransform);
                normal = System.Numerics.Vector3.Transform(normal, GlobalTransform);

                Positions.Add(new Vector4F(
                    position.X,
                    position.Y,
                    position.Z, 0));

                Normals.Add(new Vector4F(
                    normal.X,
                    normal.Y,
                    normal.Z, 0));

                if (settings.UseTangents)
                {
                    Tangents.Add(new Vector4F(
                        vertex.Tangent.X,
                        vertex.Tangent.Y,
                        vertex.Tangent.Z, 0));
                }

                if (settings.UseBitangents)
                {
                    Bitangents.Add(new Vector4F(
                        vertex.Binormal.X,
                        vertex.Binormal.Y,
                        vertex.Binormal.Z, 0));
                }

                for (int i = 0; i < vertex.UVs?.Count; i++)
                {
                    TexCoords[i][v] = new Vector4F(
                        vertex.UVs[i].X,
                        vertex.UVs[i].Y,
                        0, 0);
                }

                for (int i = 0; i < vertex.Colors?.Count; i++)
                {
                    Colors[i][v] = new Vector4F(
                        vertex.Colors[i].X,
                        vertex.Colors[i].Y,
                        vertex.Colors[i].Z,
                        vertex.Colors[i].W);
                }

                int[] indices = new int[4];
                float[] weights = new float[4];
                for (int j = 0; j < vertex.Envelope.Weights?.Count; j++)
                {
                    int index = Array.FindIndex(fskl.Bones.Values.ToArray(), x => x.Name == vertex.Envelope.Weights[j].BoneName);
                    if (index == -1)
                        continue;

                    //Check for the index in the proper skinning index lists
                    if (fshp.VertexSkinCount > 1)
                    {
                        indices[j] = smoothIndices.IndexOf(index);
                        weights[j] = vertex.Envelope.Weights[j].Weight;
                    }
                    else
                    {
                        //Rigid indices start after smooth indices in the global index list
                        //Smooth indices can have the same bone index as a rigid one, so it's best to index the specific list
                        indices[j] = smoothIndices.Count + rigidIndices.IndexOf(index);
                        weights[j] = vertex.Envelope.Weights[j].Weight;
                    }
                }

                if (vertex.Envelope.Weights?.Count > 0 && settings.UseBoneIndices && fshp.VertexSkinCount > 0)
                {
                    BoneWeights.Add(new Vector4F(weights[0], weights[1], weights[2], weights[3]));
                    BoneIndices.Add(new Vector4F(indices[0], indices[1], indices[2], indices[3]));
                }
            }

            List<VertexBufferHelperAttrib> attributes = new List<VertexBufferHelperAttrib>();
            attributes.Add(new VertexBufferHelperAttrib()
            {
                Name = "_p0",
                Data = Positions.ToArray(),
                Format = settings.PositionFormat,
            });

            if (Normals.Count > 0)
            {
                attributes.Add(new VertexBufferHelperAttrib()
                {
                    Name = "_n0",
                    Data = Normals.ToArray(),
                    Format = settings.NormalFormat,
                });
            }

            if (Tangents.Count > 0)
            {
                attributes.Add(new VertexBufferHelperAttrib()
                {
                    Name = "_t0",
                    Data = Tangents.ToArray(),
                    Format = settings.TangentFormat,
                });
            }

            if (Bitangents.Count > 0)
            {
                attributes.Add(new VertexBufferHelperAttrib()
                {
                    Name = "_b0",
                    Data = Bitangents.ToArray(),
                    Format = settings.BitangentFormat,
                });
            }

            for (int i = 0; i < TexCoords.Length; i++)
            {
                if (settings.UseTexCoord[i])
                {
                    attributes.Add(new VertexBufferHelperAttrib()
                    {
                        Name = $"_u{i}",
                        Data = TexCoords[i],
                        Format = settings.TexCoordFormat,
                    });
                }
            }

            for (int i = 0; i < Colors.Length; i++)
            {
                if (settings.UseColor[i])
                {
                    attributes.Add(new VertexBufferHelperAttrib()
                    {
                        Name = $"_c{i}",
                        Data = Colors[i],
                        Format = settings.ColorFormat,
                    });
                }
            }

            if (BoneIndices.Count > 0)
            {
                attributes.Add(new VertexBufferHelperAttrib()
                {
                    Name = "_i0",
                    Data = BoneIndices.ToArray(),
                    Format = settings.BoneIndicesFormat,
                });
            }

            if (BoneWeights.Count > 0)
            {
                attributes.Add(new VertexBufferHelperAttrib()
                {
                    Name = "_w0",
                    Data = BoneWeights.ToArray(),
                    Format = settings.BoneWeightsFormat,
                });
            }

            vertexBufferHelper.Attributes = attributes;
            var buffer = vertexBufferHelper.ToVertexBuffer();
            buffer.VertexSkinCount = (byte)fshp.VertexSkinCount;
            return buffer;
        }

        public class MeshSettings
        {
            public bool UseNormal { get; set; }
            public bool[] UseTexCoord { get; set; }
            public bool[] UseColor { get; set; }
            public bool UseBoneWeights { get; set; }
            public bool UseBoneIndices { get; set; }
            public bool UseTangents { get; set; }
            public bool UseBitangents { get; set; }

            public GX2AttribFormat PositionFormat = GX2AttribFormat.Format_32_32_32_Single;
            public GX2AttribFormat NormalFormat = GX2AttribFormat.Format_10_10_10_2_SNorm;
            public GX2AttribFormat TexCoordFormat = GX2AttribFormat.Format_16_16_Single;
            public GX2AttribFormat ColorFormat = GX2AttribFormat.Format_16_16_16_16_Single;
            public GX2AttribFormat TangentFormat = GX2AttribFormat.Format_8_8_8_8_SNorm;
            public GX2AttribFormat BitangentFormat = GX2AttribFormat.Format_8_8_8_8_SNorm;

            public GX2AttribFormat BoneIndicesFormat = GX2AttribFormat.Format_8_8_8_8_UInt;
            public GX2AttribFormat BoneWeightsFormat = GX2AttribFormat.Format_8_8_8_8_UNorm;
        }
    }
}
