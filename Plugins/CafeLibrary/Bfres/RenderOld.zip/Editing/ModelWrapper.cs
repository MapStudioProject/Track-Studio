﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BfresLibrary;
using BfresLibrary.GX2;
using Toolbox.Core;
using BfresLibrary.Helpers;
using OpenTK;
using MapStudio.UI;
using CafeLibrary.ModelConversion;
using Toolbox.Core.ViewModels;
using CafeLibrary.Rendering;
using GLFrameworkEngine;

namespace CafeLibrary
{
    public class ModelFolder : NodeBase
    {
        public override string Header => "Models";

        public ResFile ResFile { get; set; }

        public ModelFolder(BFRES bfres, ResFile resFile)
        {
            ResFile = resFile;

            foreach (var model in ResFile.Models.Values)
            {
                FMDL fmdl = new FMDL(bfres, resFile, model);
                this.AddChild(fmdl.UINode);
            }
        }

        public void OnSave()
        {
            foreach (var modelNode in Children)
            {
                FMDL fmdl = (FMDL)modelNode.Tag;
                foreach (FSHP fshp in fmdl.Meshes) {
                    fshp.Shape.VertexBufferIndex = (ushort)fmdl.Model.VertexBuffers.IndexOf(fshp.VertexBuffer);
                }
            }
        }
    }

    /// <summary>
    /// Represents a wrapper to edit UI, render and bfres model data
    /// </summary>
    public class FMDL : STGenericModel, IContextMenu
    {
        public Model Model { get; set; }
        public ResFile ResFile { get; set; }
        public BFRES BfresWrapper { get; set; }

        //UI Folders
        private readonly NodeBase SkeletonFolder = new NodeBase("Skeleton");
        private readonly NodeBase MeshFolder = new NodeBase("Meshes");
        private readonly NodeBase MaterialFolder = new NodeBase("Materials");
        //UI Node
        public NodeBase UINode;

        //
        public BfresModelRender ModelRenderer;

        public FMDL(BFRES bfres, ResFile resFile, Model model)
        {
            BfresWrapper = bfres;
            ResFile = resFile;
            Model = model;

            //UI nodes
            UINode = new NodeBase(model.Name);
            UINode.Tag = this;
            UINode.AddChild(MeshFolder);
            UINode.AddChild(MaterialFolder);
            UINode.AddChild(SkeletonFolder);

            MaterialFolder.ContextMenus.Add(new MenuItemModel("Add Material", AddMaterialDialog));

            //Skeletons, materials and meshes
            this.Skeleton = new FSKL(model.Skeleton);
            foreach (var mat in model.Materials.Values) {
                Materials.Add(new FMAT(resFile, mat));
            }
            foreach (var shape in model.Shapes.Values) {
                Meshes.Add(new FSHP(resFile, (FSKL)Skeleton, model, shape, Materials));
            }
            //Add UI
            foreach (FMAT mat in Materials)
                MaterialFolder.AddChild(mat.UINode);
            foreach (FSHP mesh in Meshes)
                MeshFolder.AddChild(mesh.UINode);

            //Load the renderer
            ModelRenderer = BfresLoader.PrepareModel(bfres.Renderer, resFile, model);
            bfres.Renderer.Models.Add(ModelRenderer);

            foreach (FMAT mat in Materials) {
                var mesh = ModelRenderer.Meshes.FirstOrDefault(x => x.MaterialAsset.Name == mat.Name);
                if (mesh != null)
                mat.MaterialAsset = (BfresMaterialRender)mesh.MaterialAsset;
            }
            foreach (FSHP mesh in Meshes) {
                mesh.MeshAsset = (BfresMeshRender)ModelRenderer.Meshes.FirstOrDefault(x => x.Name == mesh.Name);
                mesh.SetupRender(mesh.MeshAsset);
            }
        }

        public MenuItemModel[] GetContextMenuItems()
        {
            return new MenuItemModel[]
            {
                new MenuItemModel("Export", ExportDialog),
                new MenuItemModel("Replace", ReplaceDialog),
                new MenuItemModel(""),
                new MenuItemModel("Add", AddModelDialog),
            };
        }

        private void AddMaterialDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.MultiSelect = true;
            dlg.AddFilter(".json", ".json");
            dlg.AddFilter(".bfmat", ".bfmat");

            if (dlg.ShowDialog())
            {
                foreach (var file in dlg.FilePaths)
                    AddMaterialDialog(file);
            }
        }

        public void AddMaterialDialog(string filePath)
        {
            Material material = new Material();
            material.Import(filePath, ResFile);

            var fmat = new FMAT(ResFile, material);
            Materials.Add(fmat);
            MaterialFolder.AddChild(fmat.UINode);
        }

        private void ExportDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.SaveDialog = true;
            dlg.FileName = $"{this.Model.Name}.dae";
            dlg.AddFilter(".bfmdl", ".bfmdl");
            dlg.AddFilter(".dae", ".dae");

            if (dlg.ShowDialog())
            {
                if (dlg.FilePath.EndsWith(".bfmdl"))
                    Model.Export(dlg.FilePath, ResFile);
                else
                {
                    var scene = BfresModelExporter.FromGeneric(ResFile, Model);
                    IONET.IOManager.ExportScene(scene, dlg.FilePath);
                    BfresWrapper.ExportTextures(System.IO.Path.GetDirectoryName(dlg.FilePath));
                }
            }
        }

        private void ReplaceDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.SaveDialog = false;
            dlg.AddFilter(".bfmdl", ".bfmdl");
            dlg.AddFilter(".dae", ".dae");
            dlg.AddFilter(".fbx", ".fbx");

            if (dlg.ShowDialog())
            {
                Model = BfresModelImporter.ImportModel(ResFile, dlg.FilePath);
                Model.Name = UINode.Header;

                BfresWrapper.Renderer.Models.Remove(ModelRenderer);

                ModelRenderer = BfresLoader.PrepareModel(BfresWrapper.Renderer, ResFile, Model);
                BfresWrapper.Renderer.Models.Add(ModelRenderer);

                GLContext.ActiveContext.UpdateViewport = true;
            }
        }

        private void AddModelDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.SaveDialog = false;
            dlg.AddFilter(".bfmdl", ".bfmdl");
            dlg.AddFilter(".dae", ".dae");
            dlg.AddFilter(".fbx", ".fbx");

            if (dlg.ShowDialog())
                AddModel(dlg.FilePath);
        }

        public void RemoveMesh(FSHP fshp)
        {
            MeshFolder.Children.Remove(fshp.UINode);
            Model.Shapes.Remove(fshp.Shape);
            Model.VertexBuffers.Remove(fshp.VertexBuffer);
        }

        public void AddModel(string filePath)
        {
            //Adding models will be merged instead
            var importedModel = BfresModelImporter.ImportModel(ResFile, filePath);
            foreach (var vertexBuffer in importedModel.VertexBuffers)
                Model.VertexBuffers.Add(vertexBuffer);

            foreach (var mat in importedModel.Materials.Values)
            {
                //Only add new instances of materials. 
                //Assume that the current materials are wanted to be kept
                if (!Model.Materials.ContainsKey(mat.Name) && !string.IsNullOrEmpty(mat.Name))
                {
                    Model.Materials.Add(mat.Name, mat);

                    //Load material into gui
                    var fmat = new FMAT(ResFile, mat);
                    Materials.Add(fmat);
                    MaterialFolder.AddChild(fmat.UINode);
                }
            }

            foreach (var shape in importedModel.Shapes.Values)
            {
                if (Model.Shapes.ContainsKey(shape.Name))
                {
                    //update the shape name so it isn't duplicated
                    shape.Name = Utils.RenameDuplicateString(shape.Name, importedModel.Shapes.Keys.ToList());
                }

                //Update material index based on the current model
                var mat = importedModel.Materials[shape.MaterialIndex];
                if (!string.IsNullOrEmpty(mat.Name))
                    shape.MaterialIndex = (ushort)Model.Materials.Keys.ToList().IndexOf(mat.Name);

                //Update vertex buffer index based on the current model
                var vertexBuffer = importedModel.VertexBuffers[shape.VertexBufferIndex];
                shape.VertexBufferIndex = (ushort)Model.VertexBuffers.IndexOf(vertexBuffer);
                //Add to model
                Model.Shapes.Add(shape.Name, shape);

                //Load mesh into gui
                var fshp = new FSHP(ResFile, (FSKL)Skeleton, Model, shape, Materials);
                Meshes.Add(fshp);
                MeshFolder.AddChild(fshp.UINode);
            }

            //Add to renderer
            foreach (var shape in importedModel.Shapes.Values)
               BfresLoader.AddMesh(ResFile, BfresWrapper.Renderer, ModelRenderer, Model, shape);

            foreach (FSHP mesh in Meshes)
            {
                if (mesh.MeshAsset != null)
                    continue;

                //Update the mesh renderer
                mesh.MeshAsset = (BfresMeshRender)ModelRenderer.Meshes.FirstOrDefault(x => x.Name == mesh.Name);
                mesh.SetupRender(mesh.MeshAsset);
            }
        }
    }

    public class FSKL : STSkeleton
    {
        public Skeleton Skeleton { get; set; }

        public FSKL(Skeleton skeleton)
        {
            Skeleton = skeleton;

            Reload();
        }

        public void Reload()
        {
            foreach (var bone in Skeleton.Bones.Values)
            {
                var genericBone = new STBone(this)
                {
                    Name = bone.Name,
                    ParentIndex = bone.ParentIndex,
                    Position = new OpenTK.Vector3(
                        bone.Position.X,
                        bone.Position.Y,
                        bone.Position.Z),
                    Scale = new OpenTK.Vector3(
                        bone.Scale.X,
                        bone.Scale.Y,
                        bone.Scale.Z),
                };

                if (bone.FlagsRotation == BoneFlagsRotation.EulerXYZ)
                {
                    genericBone.EulerRotation = new OpenTK.Vector3(
                        bone.Rotation.X, bone.Rotation.Y, bone.Rotation.Z);
                }
                else
                    genericBone.Rotation = new OpenTK.Quaternion(
                         bone.Rotation.X, bone.Rotation.Y,
                         bone.Rotation.Z, bone.Rotation.W);

                Bones.Add(genericBone);
            }

            Reset();
        }
    }

    /// <summary>
    /// Represents a wrapper to edit UI, render and bfres material data
    /// </summary>
    public class FMAT : STGenericMaterial, IContextMenu, IPropertyUI, IDragDropNode
    {
        /// <summary>
        /// The bfres material data.
        /// </summary>
        public Material Material { get; set; }

        /// <summary>
        /// The bfres data.
        /// </summary>
        public ResFile ResFile { get; set; }

        /// <summary>
        /// The UI tree node.
        /// </summary>
        public NodeBase UINode { get; set; }

        /// <summary>
        /// The name of the material.
        /// </summary>
        public override string Name
        {
            get { return Material.Name; }
            set { 
                Material.Name = value;
                //Update UI too
                if (UINode.Header != value)
                    UINode.Header = value;
            }
        }

        /// <summary>
        /// The shader archive name.
        /// </summary>
        public string ShaderArchive
        {
            get
            {
                if (Material.ShaderAssign == null)
                    return "";
                return Material.ShaderAssign.ShaderArchiveName;
            }
        }

        /// <summary>
        /// The shader model name.
        /// </summary>
        public string ShaderModel
        {
            get
            {
                if (Material.ShaderAssign == null)
                    return "";
                return Material.ShaderAssign.ShadingModelName;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<string, ShaderParam> AnimatedParams = new Dictionary<string, ShaderParam>();

        /// <summary>
        /// 
        /// </summary>
        public BfresMaterialRender MaterialAsset;

        /// <summary>
        /// Checks if the material is valid or not. 
        /// Determines based on having empty render data or not.
        /// </summary>
        public bool IsMaterialInvalid => Material.RenderInfos.Count == 0;

        public CullMode CullState
        {
            get
            {
                if (CullFront && CullBack) return CullMode.Both;
                else if (CullBack) return CullMode.Back;
                else if (CullFront) return CullMode.Front;
                else
                    return CullMode.None;
            }
            set
            {
                CullBack = false;
                CullFront = false;

                if (value == CullMode.Both)
                {
                    CullBack = true;
                    CullFront = true;
                }
                else if (value == CullMode.Front)
                    CullFront = true;
                else if (value == CullMode.Back)
                    CullBack = true;
            }
        }

        public enum CullMode
        {
            None,
            Front,
            Back,
            Both,
        }

        public bool CullFront = false;
        public bool CullBack = true;

        public FMAT(ResFile resFile, Material mat)
        {
            ResFile = resFile;
            Material = mat;
            UINode = new NodeBase(mat.Name);
            UINode.Tag = this;
            UINode.Icon = $"material_{this.Name}";
            UINode.IconDrawer += delegate
            {
                DrawIcon();
            };
            ReloadMaterial(mat);
        }

        public void DrawIcon()
        {
            if (IsMaterialInvalid)
                this.UINode.Icon = IconManager.WARNING_ICON.ToString();

            if (MaterialAsset == null)
                return; 

            if (!IconManager.HasIcon(UINode.Icon)) {
                GLTexture tex = MaterialAsset.RenderIcon(64);
                IconManager.TryAddIcon(UINode.Icon, tex);
            }
        }

        public void ReloadTextureMap(int index)
        {
            var texSampler = Material.Samplers[index].TexSampler;
            var texMap = this.TextureMaps[index];

            texMap.MagFilter = BfresMatGLConverter.ConvertMagFilter(texSampler.MagFilter);
            texMap.MinFilter = BfresMatGLConverter.ConvertMinFilter(
                       texSampler.MipFilter,
                       texSampler.MinFilter);
            texMap.WrapU = BfresMatGLConverter.ConvertWrapMode(texSampler.ClampX);
            texMap.WrapV = BfresMatGLConverter.ConvertWrapMode(texSampler.ClampY);
            texMap.LODBias = texSampler.LodBias;
            texMap.MaxLOD = texSampler.MaxLod;
            texMap.MinLOD = texSampler.MinLod;

            Material.TextureRefs[index].Name = texMap.Name;

            if (MaterialAsset != null)
            {
                MaterialAsset.TextureMaps.Clear();
                MaterialAsset.TextureMaps.AddRange(this.TextureMaps);

                GLTexture tex = MaterialAsset.RenderIcon(64);
                IconManager.TryAddIcon(UINode.Icon, tex, true);
            }
            GLContext.ActiveContext.UpdateViewport = true;
        }

        private STTextureType GetTextureType(string sampler)
        {
            switch (sampler)
            {
                case "_a0": return STTextureType.Diffuse;
                case "_n0": return STTextureType.Normal;
                case "_s0": return STTextureType.Specular;
                case "_e0": return STTextureType.Emission;
                default:
                    return STTextureType.None;
            }
        }

        public MenuItemModel[] GetContextMenuItems()
        {
            return new MenuItemModel[]
            {
                new MenuItemModel("Export", ExportDialog),
                new MenuItemModel("Replace", ReplaceDialog),
            };
        }

        public Type GetTypeUI() => typeof(BfresMaterialEditor);

        public void OnLoadUI(object uiInstance) { }

        public void OnRenderUI(object uiInstance) {
            var editor = (BfresMaterialEditor)uiInstance;
            editor.LoadEditor(this);
        }

        public void UpdateRenderState()
        {
            // MaterialAsset.ReloadRenderState(Material, meshRender);

            if (MaterialAsset != null) {
                MaterialAsset.CullFront = this.CullFront;
                MaterialAsset.CullBack = this.CullBack;
            }
            GLContext.ActiveContext.UpdateViewport = true;
        }

        private void ExportDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.SaveDialog = true;
            dlg.FileName = $"{Material.Name}.json";
            dlg.AddFilter(".bfmat", ".bfmat");
            dlg.AddFilter(".json", ".json");

            if (dlg.ShowDialog()) {
                Material.Export(dlg.FilePath, ResFile);
            }
        }

        private void ReplaceDialog()
        {
            var dlg = new ImguiFileDialog();
            dlg.SaveDialog = false;
            dlg.AddFilter(".bfmat", ".bfmat");
            dlg.AddFilter(".json", ".json");

            if (dlg.ShowDialog())
            {
                Material.Import(dlg.FilePath, ResFile);
                ReloadMaterial(Material);

                //Update based on the index used. Each mesh assigned should be updated
                var fmdl = UINode.Parent.Parent.Tag as FMDL;
                foreach (FSHP mesh in fmdl.Meshes)
                {
                    if (this == mesh.Material)
                        mesh.UpdateMaterial();
                }

                if (MaterialAsset != null)
                {
                    MaterialAsset.TextureMaps.Clear();
                    MaterialAsset.TextureMaps.AddRange(this.TextureMaps);

                    GLTexture tex = MaterialAsset.RenderIcon(64);
                    IconManager.TryAddIcon(UINode.Icon, tex, true);
                }
            }
        }

        public void ReloadMaterial(Material material)
        {
            Material = material;
            Material.Name = UINode.Header;

            this.TextureMaps.Clear();
            for (int i = 0; i < Material.TextureRefs.Count; i++)
            {
                string name = Material.TextureRefs[i].Name;
                Sampler sampler = Material.Samplers[i];
                var texSampler = Material.Samplers[i].TexSampler;
                string samplerName = sampler.Name;
                string fragSampler = "";

                //Force frag shader sampler to be used 
                if (Material.ShaderAssign.SamplerAssigns.ContainsValue(samplerName))
                    Material.ShaderAssign.SamplerAssigns.TryGetKey(samplerName, out fragSampler);

                this.TextureMaps.Add(new STGenericTextureMap()
                {
                    Name = name,
                    Sampler = samplerName,
                    MagFilter = BfresMatGLConverter.ConvertMagFilter(texSampler.MagFilter),
                    MinFilter = BfresMatGLConverter.ConvertMinFilter(
                        texSampler.MipFilter,
                        texSampler.MinFilter),
                    Type = GetTextureType(fragSampler),
                    WrapU = BfresMatGLConverter.ConvertWrapMode(texSampler.ClampX),
                    WrapV = BfresMatGLConverter.ConvertWrapMode(texSampler.ClampY),
                    LODBias = texSampler.LodBias,
                    MaxLOD = texSampler.MaxLod,
                    MinLOD = texSampler.MinLod,
                });
            }
        }

        public string GetAlbedoTexture()
        {
            for (int i = 0; i < TextureMaps.Count; i++)
            {
                if (Material.Samplers[i].Name == "_a0")
                    return TextureMaps[i].Name;
            }
            return "";
        }
    }

    public class FSHP : STGenericMesh, IPropertyUI
    {
        /// <summary>
        /// The shape section storing face indices and bounding data.
        /// </summary>
        public Shape Shape { get; set; }

        /// <summary>
        /// The vertex buffer storing vertex data and attributes.
        /// </summary>
        public VertexBuffer VertexBuffer { get; set; }

        /// <summary>
        /// The model in which the data in this section is parented to.
        /// </summary>
        public Model ParentModel { get; set; }

        /// <summary>
        /// The material data mapped to the mesh.
        /// </summary>
        public FMAT Material { get; set; }

        /// <summary>
        /// The skeleton used in the parent model.
        /// </summary>
        public FSKL ParentSkeleton { get; set; }

        /// <summary>
        /// The file in which the data in this section is parented to.
        /// </summary>
        public ResFile ParentFile { get; set; }

        /// <summary>
        /// The UI tree node.
        /// </summary>
        public NodeBase UINode { get; set; }

        /// <summary>
        /// The mesh renderer.
        /// </summary>
        public BfresMeshRender MeshAsset { get; set; }

        //material assignment before being changed
        private FMAT beforeDroppedMaterial;
        private string beforeDroppedTexture;

        public void SetupRender(BfresMeshRender meshRender) {
            MeshAsset = meshRender;
            //Attach a tree node to the renderer. This will allow scrolling to outliner when renderer is selected
            MeshAsset.UINode = this.UINode;
            MeshAsset.OnRemoved += delegate
            {
                var fmdl = this.UINode.Parent.Parent.Tag as FMDL;
                fmdl.RemoveMesh(this);
            };
            //Setup drag/drop events
            //The user can drag/drop tree nodes and other UI elements to the mesh itself
            MeshAsset.OnDragDropped += (droppedItem, e) =>
            {
                //Dropped texture
                if (droppedItem is STGenericTexture)
                {
                    string name = ((STGenericTexture)droppedItem).Name;
                    AssignTextureToMaterial(name);
                }
                //Dropped material
                if (droppedItem is FMAT) {
                    AssignMaterial((FMAT)droppedItem);
                }
            };
            MeshAsset.OnDragDroppedOnEnter += delegate
            {
                beforeDroppedMaterial = this.Material;
                beforeDroppedTexture = Material.GetAlbedoTexture();
            };
            MeshAsset.OnDragDroppedOnLeave += delegate
            {
                if (beforeDroppedMaterial != null)
                    AssignMaterial(beforeDroppedMaterial);
                if (beforeDroppedTexture != null)
                    AssignTextureToMaterial(beforeDroppedTexture);
            };
        }

        private void AssignTextureToMaterial(string name)
        {
            for (int i = 0; i < Material.TextureMaps.Count; i++)
            {
                if (Material.Material.Samplers[i].Name == "_a0") {
                    Material.TextureMaps[i].Name = name;
                    Material.ReloadTextureMap(i);
                }
            }
        }

        public Type GetTypeUI() => typeof(BfresMaterialEditor);

        public void OnLoadUI(object uiInstance) { }

        public void OnRenderUI(object uiInstance)
        {
            var editor = (BfresMaterialEditor)uiInstance;
            editor.LoadEditor(this.Material);
        }

        private void AssignMaterial(FMAT fmat)
        {
            if (Material == fmat)
                return;

            int index = ParentModel.Materials.IndexOf(fmat.Material);
            if (index == -1)
                return;

            Shape.MaterialIndex = (ushort)index;
            Material = fmat;

            UpdateMaterial();
        }

        public void UpdateMaterial()
        {
            var fmdl = this.UINode.Parent.Parent.Tag as FMDL;

            BfresLoader.UpdateMaterial(fmdl.BfresWrapper.Renderer,
                fmdl.ModelRenderer, MeshAsset, Shape, Material.Material);

            Material.MaterialAsset = (BfresMaterialRender)MeshAsset.MaterialAsset;
        }

        public FSHP(ResFile resFile, FSKL skeleton, Model model, Shape shape, List<STGenericMaterial> materials)
        {
            ParentFile = resFile;
            ParentModel = model;
            Shape = shape;
            ParentSkeleton = skeleton;
            BoneIndex = shape.BoneIndex;
            VertexBuffer = model.VertexBuffers[shape.VertexBufferIndex];
            Material = (FMAT)materials[shape.MaterialIndex];
            VertexSkinCount = shape.VertexSkinCount;
            UINode = new NodeBase(shape.Name);
            UINode.Tag = this;

            Name = shape.Name;

            UpdateVertexBuffer();
            UpdatePolygonGroups();
        }

        public void UpdateTransform()
        {
            int boneIndex = Shape.BoneIndex;
            var bone = ParentSkeleton.Bones[boneIndex];
            this.Transform = new ModelTransform()
            {
                Position = bone.AnimationController.Position,
                Rotation = bone.AnimationController.Rotation,
                Scale = bone.AnimationController.Scale,
            };
            this.Transform.Update();
        }

        /// <summary>
        /// Updates the current buffer from the shapes vertex buffer data.
        /// </summary>
        public void UpdateVertexBuffer()
        {
            //Load the vertex buffer into the helper to easily access the data.
            VertexBufferHelper helper = new VertexBufferHelper(VertexBuffer, ParentFile.ByteOrder);

            //Loop through all the vertex data and load it into our vertex data
            Vertices = new List<STVertex>();

            //Get all the necessary attributes
            var positions = TryGetValues(helper, "_p0");
            var normals = TryGetValues(helper, "_n0");
            var texCoords = TryGetChannelValues(helper, "_u");
            var colors = TryGetChannelValues(helper, "_c");
            var tangents = TryGetValues(helper, "_t0");
            var bitangents = TryGetValues(helper, "_b0");
            var weights0 = TryGetValues(helper, "_w0");
            var indices0 = TryGetValues(helper, "_i0");

            var boneIndexList = ParentSkeleton.Skeleton.MatrixToBoneList;

            if (VertexSkinCount == 0)
                UpdateTransform();

            //Get the position attribute and use the length for the vertex count
            for (int v = 0; v < positions.Length; v++)
            {
                STVertex vertex = new STVertex();
                Vertices.Add(vertex);

                vertex.Position = new Vector3(positions[v].X, positions[v].Y, positions[v].Z);
                if (normals.Length > 0)
                    vertex.Normal = new Vector3(normals[v].X, normals[v].Y, normals[v].Z);

                if (texCoords.Length > 0)
                {
                    vertex.TexCoords = new Vector2[texCoords.Length];
                    for (int i = 0; i < texCoords.Length; i++)
                        vertex.TexCoords[i] = new Vector2(texCoords[i][v].X, texCoords[i][v].Y);
                }
                if (colors.Length > 0)
                {
                    vertex.Colors = new Vector4[colors.Length];
                    for (int i = 0; i < colors.Length; i++)
                        vertex.Colors[i] = new Vector4(
                            colors[i][v].X, colors[i][v].Y,
                            colors[i][v].Z, colors[i][v].W);
                }

                if (tangents.Length > 0)
                    vertex.Tangent = new Vector4(tangents[v].X, tangents[v].Y, tangents[v].Z, tangents[v].W);
                if (bitangents.Length > 0)
                    vertex.Bitangent = new Vector4(bitangents[v].X, bitangents[v].Y, bitangents[v].Z, bitangents[v].W);

                for (int i = 0; i < VertexBuffer.VertexSkinCount; i++)
                {
                    if (i > 3)
                        break;

                    int index = boneIndexList[(int)indices0[v][i]];
                    vertex.BoneIndices.Add(index);
                    if (weights0.Length > 0)
                        vertex.BoneWeights.Add(weights0[v][i]);
                    else
                        vertex.BoneWeights.Add(1.0f);

                    if (VertexSkinCount == 1)
                    {
                        var bone = ParentSkeleton.Bones[index];
                        vertex.Position = Vector3.TransformPosition(vertex.Position, bone.Transform);
                        vertex.Normal = Vector3.TransformNormal(vertex.Normal, bone.Transform);
                    }
                }
            }
        }

        //Gets attributes with more than one channel
        private Syroot.Maths.Vector4F[][] TryGetChannelValues(VertexBufferHelper helper, string attribute)
        {
            List<Syroot.Maths.Vector4F[]> channels = new List<Syroot.Maths.Vector4F[]>();
            for (int i = 0; i < 10; i++)
            {
                if (helper.Contains($"{attribute}{i}"))
                    channels.Add(helper[$"{attribute}{i}"].Data);
                else
                    break;
            }
            return channels.ToArray();
        }

        //Gets the attribute data given the attribute key.
        private Syroot.Maths.Vector4F[] TryGetValues(VertexBufferHelper helper, string attribute)
        {
            if (helper.Contains(attribute))
                return helper[attribute].Data;
            else
                return new Syroot.Maths.Vector4F[0];
        }

        /// <summary>
        /// Updates the current polygon groups from the shape data.
        /// </summary>
        public void UpdatePolygonGroups()
        {
            PolygonGroups = new List<STPolygonGroup>();
            foreach (var mesh in Shape.Meshes)
            {
                //Set group as a level of detail
                var group = new STPolygonGroup();
                group.Material = Material;
                group.GroupType = STPolygonGroupType.LevelOfDetail;
                //Load indices into the group
                var indices = mesh.GetIndices().ToArray();
                for (int i = 0; i < indices.Length; i++)
                    group.Faces.Add(indices[i]);

                if (!PrimitiveTypes.ContainsKey(mesh.PrimitiveType))
                    throw new Exception($"Unsupported primitive type! {mesh.PrimitiveType}");

                //Set the primitive type
                group.PrimitiveType = PrimitiveTypes[mesh.PrimitiveType];
                //Set the face offset (used for level of detail meshes)
                group.FaceOffset = (int)mesh.SubMeshes[0].Offset;
                PolygonGroups.Add(group);
                break;
            }
        }

        //Converts bfres primitive types to generic types used for rendering.
        Dictionary<GX2PrimitiveType, STPrimitiveType> PrimitiveTypes = new Dictionary<GX2PrimitiveType, STPrimitiveType>()
        {
            { GX2PrimitiveType.Triangles, STPrimitiveType.Triangles },
            { GX2PrimitiveType.LineLoop, STPrimitiveType.LineLoop },
            { GX2PrimitiveType.Lines, STPrimitiveType.Lines },
            { GX2PrimitiveType.TriangleFan, STPrimitiveType.TriangleFans },
            { GX2PrimitiveType.Quads, STPrimitiveType.Quad },
            { GX2PrimitiveType.QuadStrip, STPrimitiveType.QuadStrips },
            { GX2PrimitiveType.TriangleStrip, STPrimitiveType.TriangleStrips },
        };
    }
}
