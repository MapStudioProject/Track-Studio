﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Collections.ObjectModel;
using Toolbox.Core.ViewModels;
using Toolbox.Core;
using MapStudio.UI;
using BfresLibrary;
using CafeLibrary.Rendering;
using Syroot.NintenTools.NSW.Bntx;

namespace CafeLibrary
{
    /// <summary>
    /// Represents a tree node for texture editing.
    /// </summary>
    public class TextureNode : NodeBase
    {
        public TextureNode(STGenericTexture tex) : base(tex.Name)
        {
            this.Tag = tex;

            ContextMenus.Add(new MenuItemModel("Export", ExportTextureDialog));
            ContextMenus.Add(new MenuItemModel("Replace", ReplaceTextureDialog));
            ContextMenus.Add(new MenuItemModel(""));
            ContextMenus.Add(new MenuItemModel("Rename", RenameTexture));
            ContextMenus.Add(new MenuItemModel(""));
            ContextMenus.Add(new MenuItemModel("Delete", () =>
            {
                int result = TinyFileDialog.MessageBoxInfoYesNo("Are you sure you want to remove these textures? Operation cannot be undone.");
                if (result != 1)
                    return;

                RemoveTexture(true);
            }));

            tex.DisplayPropertiesChanged += (o, e) =>
            {
                //Reload the display texture
                if (tex is FtexTexture)
                    ((FtexTexture)tex).ReloadImage();
                if (tex is BntxTexture)
                    ((BntxTexture)tex).ReloadImage();

                if (tex.Name != this.Header)
                    this.Header = tex.Name;

                ((TextureFolder)this.Parent).OnTextureEdited?.Invoke(this, EventArgs.Empty);
            };
        }

        private void ExportTextureDialog()
        {
            //Multi select export
            var selected = this.Parent.Children.Where(x => x.IsSelected).ToList();
            if (selected.Count > 1)
            {
                ImguiFolderDialog dlg = new ImguiFolderDialog();
                //Todo configurable formats for folder dialog
                if (dlg.ShowDialog())
                {
                    var tex = this.Tag as STGenericTexture;
                    tex.Export($"{dlg.SelectedPath}\\{tex.Name}.png", new TextureExportSettings());
                }
            }
            else
            {
                ImguiFileDialog dlg = new ImguiFileDialog();
                dlg.SaveDialog = true;
                dlg.FileName = $"{this.Header}.png";
                dlg.AddFilter(".bftex", ".bftex");
                dlg.AddFilter(".dds", ".dds");
                foreach (var ext in TextureDialog.SupportedExtensions)
                    dlg.AddFilter(ext, ext);

                if (dlg.ShowDialog())
                {
                    var tex = this.Tag as STGenericTexture;
                    tex.Export(dlg.FilePath, new TextureExportSettings());
                }
            }
        }

        private void ReplaceTextureDialog()
        {
            //Multi select replace
            var selected = this.Parent.Children.Where(x => x.IsSelected).ToList();
            if (selected.Count > 1)
            {
                ImguiFileDialog dlg = new ImguiFileDialog();
                dlg.SaveDialog = false;
                dlg.AddFilter(".bftex", ".bftex");
                dlg.AddFilter(".dds", ".dds");
                foreach (var ext in TextureDialog.SupportedExtensions)
                    dlg.AddFilter(ext, ext);

                //Mutli replace each selected texture node with the given texture
                if (dlg.ShowDialog())
                {
                    foreach (TextureNode tex in selected)
                        tex.ReplaceTexture(dlg.FilePath);
                }
            }
            else
            {
                ImguiFileDialog dlg = new ImguiFileDialog();
                dlg.SaveDialog = false;
                dlg.AddFilter(".bftex", ".bftex");
                dlg.AddFilter(".dds", ".dds");
                foreach (var ext in TextureDialog.SupportedExtensions)
                    dlg.AddFilter(ext, ext);

                if (dlg.ShowDialog())
                    ReplaceTexture(dlg.FilePath);
            }
        }

        public void ReplaceTexture(string filePath)
        {
            var folder = this.Parent as TextureFolder;
            //Add to the replace dialog. This dialog is capable of replacing multiple files via dictionary
            folder.ReplaceTextures(new Dictionary<string, TextureNode>() {
                { filePath, this }
            });
        }

        public void ReplaceTexture(ImportedTexture importedTex)
        {
            var folder = this.Parent as TextureFolder;
            var mipmaps = importedTex.Surfaces[0].Mipmaps;
            
            List<STGenericTexture.Surface> surfaces = new List<STGenericTexture.Surface>();
            surfaces.Add(new STGenericTexture.Surface()
            {
                mipmaps = mipmaps,
            });
            //Import replaced texture and set it in bfres
            var tex = BfresTextureImporter.ImportTexture(folder.ResFile, folder.BntxFile, Header, surfaces, importedTex.Format,
                (uint)importedTex.Width, (uint)importedTex.Height, (uint)mipmaps.Count);
            folder.ResFile.Textures[Header] = tex;

            //Dispose previous
            ((STGenericTexture)this.Tag).RenderableTex?.Dispose();
            //Setup display texture
            this.Tag = BfresLoader.GetTexture(folder.ResFile, tex);
            //Update icon
            IconManager.RemoveTextureIcon(tex.Name);

            folder.OnTextureReplaced?.Invoke(this, EventArgs.Empty);
        }

        private void RenameTexture()
        {

        }

        private void RemoveTexture(bool undo = false) {
            var selected = this.Parent.Children.Where(x => x.IsSelected).ToList();
            if (selected.Count > 1)
            {
                foreach (TextureNode tex in selected)
                    ((TextureFolder)tex.Parent).RemoveTexture(tex, undo);
            }
            else
                ((TextureFolder)this.Parent).RemoveTexture(this, undo);
        }
    }

    /// <summary>
    /// Represents a tree node for texture folder editing.
    /// </summary>
    public class TextureFolder : NodeBase
    {
        public override string Header => "Textures";

        public ResFile ResFile;
        public BntxFile BntxFile;

        public EventHandler OnTextureAdded;
        public EventHandler OnTextureRemoved;
        public EventHandler OnTextureReplaced;
        public EventHandler OnTextureEdited;

        //For direct editing on bntx
        public TextureFolder(BntxFile bntx)
        {
            Init(new ResFile() { IsPlatformSwitch = true }, bntx);
        }

        //For editing bfres + bntx (optional)
        public TextureFolder(ResFile resFile, BntxFile bntx)
        {
            Init(resFile, bntx);
        }

        private void Init(ResFile resFile, BntxFile bntx)
        {
            ResFile = resFile;
            BntxFile = bntx;

            //switch embeds bntx file data
            if (ResFile.IsPlatformSwitch)
                Tag = bntx;

            this.TagUI.UIDrawer += delegate
            {
                ImguiBinder.LoadPropertiesComponentModelBase(bntx);
            };

            if (ResFile.IsPlatformSwitch)
            {
                ContextMenus.Add(new MenuItemModel("Export Bntx", ExportBntx));
                ContextMenus.Add(new MenuItemModel("Replace Bntx", ReplaceBntx));
                ContextMenus.Add(new MenuItemModel(""));
            }
            ContextMenus.Add(new MenuItemModel("Import Texture", ImportTextures));
            ContextMenus.Add(new MenuItemModel("Replace Textures (From Folder)", ReplaceTexturesFromFolder));
            ContextMenus.Add(new MenuItemModel("Export All Textures", ExportAllTextures));
            ContextMenus.Add(new MenuItemModel(""));
            ContextMenus.Add(new MenuItemModel("Sort", SortTextures));
            ContextMenus.Add(new MenuItemModel(""));
            ContextMenus.Add(new MenuItemModel("Clear", () =>
            {
                int result = TinyFileDialog.MessageBoxInfoYesNo("Are you sure you want to remove these textures? Operation cannot be undone.");
                if (result != 1)
                    return;

                Clear();
            }));

            foreach (var texture in ResFile.Textures.Values)
            {
                var tex = BfresLoader.GetTexture(ResFile, texture);
                this.AddChild(new TextureNode(tex));
            }
        }

        public void OnSave()
        {
            if (!ResFile.IsPlatformSwitch)
                return;

            //Save bntx textures from bfres
            BntxFile.Textures.Clear();
            BntxFile.TextureDict.Clear();
            foreach (BfresLibrary.Switch.SwitchTexture texture in ResFile.Textures.Values)
            {
                BntxFile.TextureDict.Add(texture.Name);
                BntxFile.Textures.Add(texture.Texture);
            }

            //Save bntx external data 
            var mem = new MemoryStream();
            BntxFile.Save(mem);

            //Apply as external data
            foreach (var externalFile in ResFile.ExternalFiles.Values)
            {
                if (externalFile.LoadedFileData is BntxFile) {
                    externalFile.Data = mem.ToArray();
                    return;
                }
            }

            //Add to external files if not in external files
            ResFile.ExternalFiles.Add("textures.bntx", new ExternalFile()
            {
                Data = mem.ToArray(),
                LoadedFileData = BntxFile,
            });
        }

        private void ExportBntx()
        {
            //Dialog for exporting bntx. 
            ImguiFileDialog fileDialog = new ImguiFileDialog();
            fileDialog.FileName = BntxFile.Name;
            fileDialog.SaveDialog = true;
            fileDialog.AddFilter(".bntx", "Texture Archive");

            if (fileDialog.ShowDialog()) {
                BntxFile.Save(fileDialog.FilePath);
            }
        }

        private void ReplaceBntx()
        {
            //Dialog for importing bntx. 
            ImguiFileDialog fileDialog = new ImguiFileDialog();
            fileDialog.SaveDialog = false;
            fileDialog.AddFilter(".bntx", "Texture Archive");

            if (fileDialog.ShowDialog()) {
                BntxFile = new BntxFile(fileDialog.FilePath);
                var textures = this.Children.ToList();
                foreach (TextureNode tex in textures)
                    RemoveTexture(tex);

                ResFile.Textures.Clear();
                foreach (var texture in BntxFile.Textures) {
                    var tex = new BntxTexture(BntxFile, texture);
                    //add to tree
                    this.AddChild(new TextureNode(tex));
                    //add to bfres
                    ResFile.Textures.Add(texture.Name, new BfresLibrary.Switch.SwitchTexture(BntxFile, texture));
                }
            }
        }

        private void Clear()
        {
            var textures = this.Children.ToList();
            foreach (TextureNode tex in textures)
                RemoveTexture(tex);
        }

        private bool ascending = true;

        private void SortTextures()
        {
            //Sort between different orders
            var sorted = ascending ?
                 Children.OrderBy(x => x.Header).ToList() :
                 Children.OrderByDescending(x => x.Header).ToList();
            //Switch order on next attempt
            ascending = !ascending;
            //Sort the collection
            for (int i = 0; i < sorted.Count; i++)
                Children.Move(Children.IndexOf(sorted[i]), i);
        }

        public void ImportTextures()
        {
            //Dialog for importing textures. 
            ImguiFileDialog fileDialog = new ImguiFileDialog();
            fileDialog.MultiSelect = true;
            foreach (var ext in TextureDialog.SupportedExtensions)
                fileDialog.AddFilter(ext, ext);
            fileDialog.AddFilter(".dds", "dds");
            fileDialog.AddFilter(".bftex", "bftex");

            if (fileDialog.ShowDialog())
            {
                var type = ResFile.IsPlatformSwitch ? typeof(BntxTexture) : typeof(FtexTexture);
                var dlg = new TextureDialog(type);

                foreach (var fileName in fileDialog.FilePaths)
                {
                    string ext = Path.GetExtension(fileName);
                    //Compressed types. (.dds2 for paint dot net dds extension)
                    if (ext == ".dds" || ext == ".dds2" || ext == ".bftex")
                        AddTexture(fileName);
                    //Use file dialog for uncompressed types
                    else
                        dlg.AddTexture(fileName);
                }
                if (dlg.Textures.Count == 0)
                    return;

                DialogHandler.Show(dlg.Name, dlg.Render, (o) =>
                {
                    if (o != true)
                        return;

                    foreach (var tex in dlg.Textures)
                    {
                        var surfaces = tex.Surfaces;
                        AddTexture(tex.Name, tex.Width, tex.Height, tex.Format, surfaces[0].Mipmaps);
                    }
                });
            }
        }

        public void ImportTexture(string filePath)
        {
            var type = ResFile.IsPlatformSwitch ? typeof(BntxTexture) : typeof(FtexTexture);
            var dlg = new TextureDialog(type);

            string ext = Path.GetExtension(filePath);
            //Compressed types. (.dds2 for paint dot net dds extension)
            if (ext == ".dds" || ext == ".dds2" || ext == ".bftex")
                AddTexture(filePath);
            //Use file dialog for uncompressed types
            else
                dlg.AddTexture(filePath);

            if (dlg.Textures.Count == 0)
                return;

            DialogHandler.Show(dlg.Name, dlg.Render, (o) =>
            {
                if (o != true)
                    return;

                foreach (var tex in dlg.Textures)
                {
                    var surfaces = tex.Surfaces;
                    AddTexture(tex.Name, tex.Width, tex.Height, tex.Format, surfaces[0].Mipmaps);
                }
            });
        }

        public void ReplaceTextures(Dictionary<string, TextureNode> texturesToReplace)
        {
            var dlg = new TextureDialog(typeof(FtexTexture));
            foreach (var texturePairs in texturesToReplace)
            {
                //file path for file
                string filePath = texturePairs.Key;
                //target texture
                var texture = texturePairs.Value;
                var textureData = texture.Tag as STGenericTexture;

                string ext = Path.GetExtension(texturePairs.Key);
                //Compressed types. (.dds2 for paint dot net dds extension)
                if (ext == ".dds" || ext == ".dds2" || ext == ".bftex")
                    texture.ReplaceTexture(filePath);
                //Use file dialog for uncompressed types
                else
                {
                    //Use the original settings by default
                    var tex = dlg.AddTexture(filePath);
                    if (tex == null) //Texture failed to load, skip
                        return;

                    tex.ChannelRed = textureData.RedChannel;
                    tex.ChannelGreen = textureData.GreenChannel;
                    tex.ChannelBlue = textureData.BlueChannel;
                    tex.ChannelAlpha = textureData.AlphaChannel;
                    tex.Format = textureData.Platform.OutputFormat;
                    tex.MipCount = textureData.MipCount;
                }
            }
            if (dlg.Textures.Count == 0)
                return;

            DialogHandler.Show(dlg.Name, dlg.Render, (o) =>
            {
                if (o != true)
                    return;

                foreach (var tex in dlg.Textures)
                {
                    var surfaces = tex.Surfaces;
                    texturesToReplace[tex.FilePath].ReplaceTexture(tex);
                }
            });
        }

        public void ExportAllTextures()
        {
            ImguiFolderDialog folderDialog = new ImguiFolderDialog();
            if (folderDialog.ShowDialog())
                ExportAllTextures(folderDialog.SelectedPath, ".png");
        }

        public void ExportAllTextures(string folder, string ext = ".png")
        {
            foreach (var tex in this.Children)
            {
                var texData = tex.Tag as STGenericTexture;
                texData.Export($"{folder}\\{tex.Header}{ext}", new TextureExportSettings());
            }
            FileUtility.OpenFolder(folder);
        }

        public void ReplaceTexturesFromFolder()
        {
            ImguiFolderDialog folderDialog = new ImguiFolderDialog();
            if (folderDialog.ShowDialog())
            {
                var textureList = new Dictionary<string, TextureNode>();
                foreach (var file in Directory.GetFiles(folderDialog.SelectedPath))
                {
                    foreach (TextureNode tex in this.Children) {
                        if (Path.GetFileNameWithoutExtension(file) == tex.Header)
                            textureList.Add(file, tex);
                    }
                }

                if (textureList.Count > 0)
                    this.ReplaceTextures(textureList);
            }
        }

        private void AddTexture(string filePath)
        {
            var tex = BfresTextureImporter.ImportTextureRaw(ResFile, BntxFile, filePath);
            ProcessNewTexture(tex);
        }

        private void AddTexture(string name, int width, int height, TexFormat format, List<byte[]> mipmaps)
        {
            List<STGenericTexture.Surface> surfaces = new List<STGenericTexture.Surface>();
            surfaces.Add(new STGenericTexture.Surface()
            {
                mipmaps = mipmaps,
            });
            var tex = BfresTextureImporter.ImportTexture(ResFile, BntxFile, name, surfaces, format, (uint)width, (uint)height, (uint)mipmaps.Count);
            ProcessNewTexture(tex);
        }

        private void ProcessNewTexture(TextureShared texture)
        {
            //Remove existing textures if names match.
            if (this.ResFile.Textures.ContainsKey(texture.Name))
            {
                this.ResFile.Textures.RemoveKey(texture.Name);
                RemoveTexture(texture.Name);
            }

            this.ResFile.Textures.Add(texture.Name, texture);
            //Reload
            var tex = BfresLoader.GetTexture(ResFile, texture);
            var texNode = new TextureNode(tex);
            this.AddChild(texNode);

            OnTextureAdded?.Invoke(texNode, EventArgs.Empty);
        }

        //Remove texture by name
        public void RemoveTexture(string name, bool undo = false)
        {
            var texNode = this.Children.FirstOrDefault(x => x.Header == name);
            RemoveTexture((TextureNode)texNode, undo);
        }

        //Remove texture by tree node removing
        public void RemoveTexture(TextureNode texNode, bool undo = false)
        {
            //Remove from bfres
            if (ResFile.Textures.ContainsKey(texNode.Header))
                ResFile.Textures.Remove(ResFile.Textures[texNode.Header]);
            //Remove from tree
            this.Children.Remove(texNode);
            //Dispose render
            var tag = texNode.Tag as STGenericTexture;
            tag.RenderableTex?.Dispose();
            //Remove icon
            IconManager.RemoveTextureIcon(texNode.Header);
            OnTextureRemoved?.Invoke(texNode, EventArgs.Empty);
        }
    }
}
