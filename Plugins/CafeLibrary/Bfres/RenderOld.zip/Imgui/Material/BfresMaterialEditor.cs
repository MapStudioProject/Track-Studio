﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImGuiNET;
using MapStudio.UI;

namespace CafeLibrary
{
    public class BfresMaterialEditor
    {
        static FMAT activeMaterial;

        static bool onLoad = false;

        static string selectedTab;

        static UVViewport UVViewport = null;

        public void Init()
        {
            UVViewport = new UVViewport();
            UVViewport.Camera.Zoom = 30;
            UVViewport.OnLoad();
        }

        public void LoadEditor(FMAT material) {
            LoadEditorMenus(material);
        }

        public void LoadEditorMenus(FMAT material)
        {
            //If the user adds a model with mapped materials that aren't in the file
            //Load just the preset UI for configuring the material to use.
            if (material.Material.RenderInfos.Count == 0) {
                DrawPresetWindow(material);
                return;
            }

            if (UVViewport == null)
                Init();

            if (activeMaterial != material)
            {
                onLoad = true;
                MaterialParameter.Reset();
                MaterialOptions.Reset();
                BfresTextureMapEditor.Reset();
                UVViewport.Reset();
            }

            activeMaterial = material;

            if (ImGui.CollapsingHeader("Material Info", ImGuiTreeNodeFlags.DefaultOpen))
            {
                ImGuiHelper.InputFromText("Name", material, "Name", 200);
                ImGuiHelper.InputFromText("ShaderArchive", material, "ShaderArchive", 200);
                ImGuiHelper.InputFromText("ShaderModel", material, "ShaderModel", 200);
                ImGuiHelper.InputFromBoolean("Visible", material.Material, "Visible");
            }

            if (ImGui.BeginChild("##MATERIAL_EDITOR"))
            {
                ImGui.BeginTabBar("Menu1");

                if (ImguiCustomWidgets.BeginTab("Menu1", "Texture Maps"))
                {
                    BfresTextureMapEditor.Render(material, UVViewport, onLoad);
                    ImGui.EndTabItem();
                }
                if (ImguiCustomWidgets.BeginTab("Menu1", "Parameters"))
                {
                    MaterialParameter.Render(material);
                    ImGui.EndTabItem();
                }
                if (ImguiCustomWidgets.BeginTab("Menu1", "Render Info"))
                {
                    RenderInfoEditor.Render(material);
                    ImGui.EndTabItem();
                }
                if (ImguiCustomWidgets.BeginTab("Menu1", "Options"))
                {
                    MaterialOptions.Render(material);
                    ImGui.EndTabItem();
                }

                if (!material.ResFile.IsPlatformSwitch)
                {
                    if (ImguiCustomWidgets.BeginTab("Menu1", "Render State"))
                    {
                        RenderStateEditor.Render(material);
                        ImGui.EndTabItem();
                    }
                }

                if (ImguiCustomWidgets.BeginTab("Menu1", "User Data"))
                {
                    UserDataInfoEditor.Render(material.Material.UserData);
                    ImGui.EndTabItem();
                }

                if (material.MaterialAsset is Rendering.BfshaRenderer) {
                    if (ImguiCustomWidgets.BeginTab("Menu1", "Shader Data"))
                    {
                        BfshaShaderProgramViewer.Render(material);
                        ImGui.EndTabItem();
                    }
                }

                ImGui.EndTabBar();
            }
            ImGui.EndChild();

            onLoad = false;
        }

        private bool keepTextures = true;
        private BfresLibrary.Material selectedMaterial;

        private void DrawPresetWindow(FMAT material)
        {
            ImGui.Text("Select a material preset to assign!");

            ImGui.Checkbox("Keep Textures", ref keepTextures);

            if (ImGui.CollapsingHeader("Resource Materials", ImGuiTreeNodeFlags.CollapsingHeader))
            {
                FMDL fmdl = material.UINode.Parent.Parent.Tag as FMDL;
                foreach (FMAT fmat in fmdl.Materials)
                {
                    if (fmat.IsMaterialInvalid)
                        continue;

                    bool select = fmat.Material == selectedMaterial;
                    if (ImGui.Selectable(fmat.Name, select))
                        selectedMaterial = fmat.Material;
                }
            }

            if (selectedMaterial != null)
            {
                if (ImGui.Button("Apply")) {
                    var textures = material.Material.TextureRefs;
                    var samplers = material.Material.Samplers;

                    material.ReloadMaterial(selectedMaterial);

                    //Assign the same textures via matching sampler types
                    for (int i = 0; i < material.Material.Samplers.Count; i++)
                    {
                        string target = material.Material.Samplers[i].Name;
                        if (samplers.ContainsKey(target)) {
                            int index = samplers.IndexOf(samplers[target]);
                            //Update texture slot
                            material.TextureMaps[i].Name = textures[index].Name;
                            material.ReloadTextureMap(i);
                        }
                    }
                }
            }
        }
    }
}
